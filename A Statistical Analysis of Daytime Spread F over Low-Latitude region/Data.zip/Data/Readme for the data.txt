Some typical cases of DSFs occurring during the afternoon hours (15-18LT) of the LSAY.
The recording time of the data files are based on Beijing local time (BJT=UT+8h), 
while the local time in Puer (LT=UT+7h) is about 1 hour earlier than Beijing time.
