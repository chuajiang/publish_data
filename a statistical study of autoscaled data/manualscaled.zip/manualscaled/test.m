dirstring = [];
Files = dir(strcat(dirstring,'*.para'));
LengthFiles = length(Files);
for i=1:LengthFiles
    oldname=[  Files(i).name];
    newname=oldname;
    newname(findstr(oldname,'��'))=[];
    command = ['rename '  oldname ' ' newname ];
    status = dos(command);
    if status == 0
        disp([oldname, ' �ѱ�������Ϊ ', newname])
    else
        disp([oldname, ' ������ʧ��!'])
    end
end